import 'package:flutter/material.dart';
import 'iniciar_sesion.dart';
import 'crear_cuentas.dart';

class MenuPrincipal extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Menú Principal')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: 
          [
                             Image.asset(
                                'assets/cor.png',
                                width: 200,
                                fit: BoxFit.cover,
                              ),
                             
                              SizedBox(height: 20), // espacio entre botones

                            ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => PIniciarSesion()),
                                );
                              },
                              child: Text('Iniciar sesión'),
                            ),

                            SizedBox(height: 20), // espacio entre botones

                            ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => PCrearCuenta()),
                                );
                              },
                              child: Text('Crear cuenta'),
                            ),
          ],
        ),
      ),
    );
  }
}
