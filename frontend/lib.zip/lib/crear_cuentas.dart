import 'package:flutter/material.dart';
import 'Cedula.dart';

class PCrearCuenta extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Crear cuenta')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: 
          [
                             Image.asset(
                                'assets/pac.jpg',
                                width: 200,
                                fit: BoxFit.cover,
                              ),
                             
                              SizedBox(height: 10), // espacio entre botones

                            ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => PCrearCuentaPaciente()),
                                );
                              },
                              child: Text('Paciente'),
                            ),

                            SizedBox(height: 60), // espacio entre botones

                             Image.asset(
                                'assets/doc.jpg',
                                width: 200,
                                fit: BoxFit.cover,
                              ),
                             
                              SizedBox(height: 10), // espacio entre botones

                            ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => PCrearCuentaMedico()),
                                );
                              },
                              child: Text('Médico'),
                            ),
          ],
        ),
      ),
    );
  }
}

class PCrearCuentaMedico extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Crear cuenta: Médico')),
      body: Center(child: Text('¡Estás en la Pantalla 2!')),
    );
  }

  
}




class PCrearCuentaPaciente extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(title: Text('Crear cuenta: Paciente ')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: 
          [
                             Image.asset(
                                'assets/cor.png',
                                width: 50,
                                fit: BoxFit.cover,
                              ),
                             
                              SizedBox(height: 20), // espacio entre botones

                              // Campo de texto para el usuario
                              ConstrainedBox(
                                      constraints: BoxConstraints(maxWidth: 400), // Ancho máximo
                                      child: TextField(
                                             decoration: InputDecoration(
                                                 labelText: 'Nombre(s)',
                                                  border: OutlineInputBorder(),
                                                  contentPadding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                                             ),
                                      ),
                              ),

                              SizedBox(height: 20), // espacio entre el campo y el siguiente

                              // Campo de texto para la contraseña
                              ConstrainedBox(
                                      constraints: BoxConstraints(maxWidth: 400),
                                      child: TextField(
                                              obscureText: true,
                                              decoration: InputDecoration(
                                                  labelText: 'Apellido Paterno',
                                                  border: OutlineInputBorder(),
                                                  contentPadding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                                            ),
                                      ),
                              ),

                            SizedBox(height: 20), // espacio entre botones

                            ElevatedButton(
                              onPressed: () {
                                //Navigator.push(
                                //  context,
                                  //MaterialPageRoute(builder: (context) => PCrearCuenta()),
                                //);
                              },
                              child: Text('Continuar'),
                            ),
          ],
        ),
      ),
      

      //Paciente paciente = Paciente(); 
    );
  }
}