import 'package:flutter/material.dart';

class PObtenerCodigo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Recuperar contraseña')),
      //body: Center(child: Text('¡Estás en la Pantalla 2!')),
    );
  }
}